package com.example.nejcvesel.pazikjehodis.retrofitAPI.Description;

import android.app.Fragment;

/**
 * Created by brani on 12/20/2016.
 */

public class HowItWorksFragment extends Fragment {

}
